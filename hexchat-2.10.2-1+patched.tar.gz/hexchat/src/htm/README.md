hexchat-theme-manager
------------------

- Shows previews of and can load/save themes
- Will run on windows/linux (still wip)

![XTM Screenshot](http://puu.sh/uoZz)